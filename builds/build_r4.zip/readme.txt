WIE MAN AR2SPELFIX INSTALLIERT:

1) �ffne deinen "Autobahn Raser II" Ordner in den Programmdateien
2) Benenne die "spel.dat" Datei in "spel.exe" um
3) Kopiere die AR2SPELFIX Dateien in den "Autobahn Raser II" Ordner

Viel Spa� mit Autobahn Raser II!

WICHTIG:
- M�glicherweise ben�tigst du die "Microsoft Visual Studio 2008 Redistributable", wenn DLL Fehler kommen
- Du brauchst umbedingt die 1.0 deutsche Version des Spiels!