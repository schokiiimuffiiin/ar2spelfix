==================
GERMAN
==================

WIE MAN AR2SPELFIX INSTALLIERT:

1) �ffne deinen "Autobahn Raser II" Ordner in den Programmdateien
2) Benenne die "spel.dat" Datei in "spel.exe" um
3) Kopiere die AR2SPELFIX Dateien in den "Autobahn Raser II" Ordner

Viel Spa� mit Autobahn Raser II!

WICHTIG:
- M�glicherweise ben�tigst du die "Microsoft Visual Studio 2008 Redistributable", wenn DLL Fehler kommen
- Du brauchst umbedingt die 1.0 deutsche Version des Spiels!

==================
ENGLISH
==================

HOW TO INSTALL AR2SPELFIX:
1) Open the "Autobahn Raser II" folder in the program files
2) Rename "spel.dat" into "spel.exe"
3) Copy the AR2SPELFIX Files into your "Autobahn Raser II" folder

Have fun with Autobahn Raser II!

IMPORTANT:
- You may require the "Microsoft Visual Studio 2008 Redistributable"
- The German 1.0 version of the game is absolutely required!

==================
https://code.google.com/p/ar2spelfix/
Written by Martin Turski